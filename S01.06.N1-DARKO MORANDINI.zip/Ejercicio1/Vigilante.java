package Ejercicio1;

public class Vigilante extends Empleado {
	
	public Vigilante(String nombre, int edad, double sueldo) {
		
		super(nombre, edad, sueldo);
	}

	
}
