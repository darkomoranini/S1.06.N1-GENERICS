package Ejercicio1;
import java.util.ArrayList;

public class NoGenericMethods<T> {

	private T obj1;
	private T obj2;
	private T obj3;
	
	public NoGenericMethods(T obj1, T obj2, T obj3) {

		this.obj1=obj1;
		this.obj2=obj2;
		this.obj3=obj3;
	}

	public void setObj(T obj1,T obj2,T obj3) {

		this.obj1=obj1;
		this.obj2=obj2;
		this.obj3=obj3;
	}

	public ArrayList<T> getObj() {
		
		ArrayList<T> list = new ArrayList<T>(3);
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
	    
		return list; 
	}


}