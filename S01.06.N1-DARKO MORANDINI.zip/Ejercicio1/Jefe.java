package Ejercicio1;

public class Jefe extends Empleado {

	public Jefe(String nombre, int edad, double salario) {
		
		super(nombre, edad, salario);
	}
	
	
}