package Ejercicio1;

public class UsoClase {

	public static void main(String[] args) {
		
		NoGenericMethods<String> objetos = new NoGenericMethods<String>();
		objetos.setObj("uno", "dos", "tres");
		NoGenericMethods<String> objetos1 = new NoGenericMethods<String>();
		objetos1.setObj("dos", "uno", "uno");
		
		System.out.println(objetos.toString());
		
		System.out.println(objetos1.toString());
		
		System.out.println(objetos.getObj());
		
		objetos.setObj("tres", "uno", "dos");
		
		
		
		
		

	}

}
