package Ejercicio1;

public class UsoClase {

	public static void main(String[] args) {
		
		NoGenericMethods<String> objetos = new NoGenericMethods<>("obj1", "obj2", "obj3");
		NoGenericMethods<String> objetos1 = new NoGenericMethods<>("obj2", "obj1", "obj3");
		NoGenericMethods<String> objetos2 = new NoGenericMethods<>("obj3", "obj2", "obj1");
		
		System.out.println(objetos.toString());
		System.out.println(objetos1.toString());
		System.out.println(objetos2.toString());
		
		
		
		
		
		
		
		

	}

}
